#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os,csv
import numpy as np
import tensorflow as tf
from sklearn import metrics
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt

def print_metrics_binary(y_true, predictions,verbose=1):

	tn, fp, fn, tp = confusion_matrix(y_true.argmax(axis=1),predictions.argmax(axis=1), labels=[0, 1]).ravel()
	acc1=(tp+tn)/(tp+tn+fp+fn)

	cf = metrics.confusion_matrix(y_true.argmax(axis=1),predictions.argmax(axis=1))

	if verbose:
		print("confusion matrix:")
		print(cf)

	cf = cf.astype(np.float32)

	correct = 0
	for i in range(0,len(cf)):
		correct += cf[i][i]
		pass
	acc = correct / np.sum(cf)

	fpr = dict()
	tpr = dict()
	roc_auc = 0
	for i in range(len(cf)):  ##iteration n_classes time
		fpr[i], tpr[i], _ = metrics.roc_curve(y_true[:, i], predictions[:, i])
		roc_auc += metrics.auc(fpr[i], tpr[i])
	auroc = roc_auc / len(cf)

	precisions = dict()
	recalls = dict()

	prc_auc = 0
	for i in range(len(cf)):  ##迭代n_classes次
		precisions[i], recalls[i], _ = metrics.precision_recall_curve(y_true[:, i], predictions[:, i])
		prc_auc += metrics.auc(recalls[i], precisions[i])
	auprc = prc_auc / len(cf)

	percision = metrics.precision_score(y_true.argmax(axis=1),predictions.argmax(axis=1))
	recall = metrics.recall_score(y_true.argmax(axis=1),predictions.argmax(axis=1))
	fscore = metrics.f1_score(y_true.argmax(axis=1),predictions.argmax(axis=1))

	if verbose:
		print('percision: ', percision)
		print('recall: ', recall)
		print('fscore: ', fscore)
		print('acc: ', acc1)
		print("accuracy = {}".format(acc))
		print("AUC of ROC = {}".format(auroc))

	return {"acc": acc,"auroc": auroc, "cf": cf,"percision":percision,"recall":recall,"fscore":fscore,"acc2":acc1}
	pass

def test_result_save(train_result,val_result,result_path,epoch):
	'''[summary]    
	Arguments:
	    train_result {[type]} -- [description]
	    val_result {[type]} -- [description]
	    result_path {[type]} -- [description]
	'''

	filename = os.path.join(result_path,"train_log.csv")

	out = open(filename,'a',newline='')

	csv_write = csv.writer(out,dialect='excel')

	if epoch == 1:
		header = ['epoch','train_loss','train_acc','train_auroc',
				'train_cf','train_percision','train_recall','train_fscore',
				'train_acc2','val_loss','val_acc','val_auroc','val_cf','val_percision','val_recall','val_fscore',
				'val_acc2']
		csv_write.writerow(header)
		pass

	content = [epoch,train_result['losses'],train_result['acc'],train_result['auroc'],
				train_result['cf'], train_result['percision'],train_result['recall'],train_result['fscore'],
				train_result['acc2'], val_result['losses'],val_result['acc'],val_result['auroc'],
				val_result['cf'],val_result['percision'],val_result['recall'],val_result['fscore'],
				val_result['acc2']]
	csv_write.writerow(content)
	pass

def val_result_save(predictions, labels, filename, val_result_savepath):

	save_file_name = os.path.join(val_result_savepath,"val_result.csv")
	out = open(save_file_name, 'a', newline='')

	csv_write = csv.writer(out, dialect='excel')
	header = ['filename','predictions','y_true']

	csv_write.writerow(header)

	for x in zip(filename, predictions, labels):
		csv_write.writerow(x)
		pass
	pass
