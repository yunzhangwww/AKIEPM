#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os,sys,argparse,imp,re,random,time
import numpy as np
import tensorflow as tf
from utils import data_load
from utils import data_load2
from utils import get_logger
from evaluate import print_metrics_binary
from evaluate import test_result_save
from evaluate import val_result_save

# Session configuration
os.environ['CUDA_VISIBLE_DEVICES'] = '0'
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'  # default: 0
config = tf.ConfigProto()
config.gpu_options.allow_growth = True
config.gpu_options.per_process_gpu_memory_fraction = 0.8

#Add program parameter
parser = argparse.ArgumentParser(description='')
parser.add_argument('--network', type=str, default="./models/AKIEPM.py", help='model structure')
parser.add_argument('--data', type=str, default='G:/my/AKIEPM/data/', help='train data')
parser.add_argument('--depth', type=int, default=2000,help='number of hidden layers')
parser.add_argument('--batch_size', type=int, default=128, help='#sample of each minibatch')#
parser.add_argument('--epoch', type=int, default=10, help='#epoch of training')
parser.add_argument('--hidden_dim', type=int, default=16, help='#dim of hidden state')
parser.add_argument('--optimizer', type=str, default='Adam', help='Adam/Adadelta/Adagrad/RMSProp/Momentum/SGD')
parser.add_argument('--beta1', type=float, default=0.9,help='beta_1 param for Adam optimizer')
parser.add_argument('--lr', type=float, default=0.00001, help='learning rate')
parser.add_argument('--clip', type=float, default=5.0, help='gradient clipping')
parser.add_argument('--dropout', type=float, default=0.95, help='dropout keep_pro')
parser.add_argument('--shuffle', type=bool, default=True, help='shuffle training data before each epoch')
parser.add_argument('--dgh', type=bool, default=True, help='add demographic information or not')
parser.add_argument('--mode',type=str,default="train",help="train/val")
parser.add_argument('--load_state',type=str,default='',help='model checkpoint path')
args = parser.parse_args()

'''
Define the model and initialize the calculation graph
'''

assert args.network is not None
print("==> using model {}".format(args.network))
model_module = imp.load_source(os.path.basename(args.network), args.network)

#num_classes：the number of class input_dim：dimension
model = model_module.Network(args, config, num_classes = 2, input_dim = 110)
model_suffix = "_dgp{}_{}".format(int(args.dgh),str(int(time.time())))
model.final_name = model.say_name() + model_suffix
print("==> model_final_name:", model.final_name)

'''
 Set various save paths for the model, including:
 Logging path:log_path
 The path of the calculation graph of the final epoch: model_path
 The save path of the predicted result: prediction_path
'''
paths = {}
modelname = model.final_name if args.load_state == '' else args.load_state
output_path = os.path.join('.',"output_save_path",modelname)
model_path = os.path.join(output_path, "checkpoints/")
result_path = os.path.join(output_path, "results")
summary_path = os.path.join(output_path, "summaries")
log_path = os.path.join(result_path, "log.txt")
paths['model_path'] = model_path
paths['summary_path'] = summary_path
model.init_model_save_path(paths)
if not os.path.exists(result_path): 
    os.makedirs(result_path)
    pass
logger = get_logger(log_path)
if args.load_state == "":
    logger.info(str(args))
    pass

'''
Determine if the model is overloaded
If the model is reloaded, read out the path of the calculation graph, and the number of recent iterations
ckpt_file、global_epoch
'''
ckpt_file = None
if args.load_state != "":
    if not os.path.exists(model_path):
        raise Exception("the folder {} is not exists".format(model_path))
    ckpt_file = tf.train.latest_checkpoint(model_path)
global_epoch = 0
if not ckpt_file == None: 
    global_epoch = int(re.findall(r'\d+', ckpt_file)[-1])
print("==>At model epoch",global_epoch)

'''
Read the data and split it into training and testing sets
'''

train_data_path = os.path.join(args.data,'TestData/train/')
train_label_path = os.path.join(args.data,'TestData/final_train.csv')
train_data = data_load(train_data_path, train_label_path, mode='train')
random.shuffle(train_data)

test_data_path = os.path.join(args.data,'TestData/test/')
test_label_path = os.path.join(args.data,'TestData/final_test.csv')
test_data = data_load2(test_data_path, test_label_path, mode='train')
random.shuffle(test_data)

'''
Read validation set data
'''

#val_data_path = os.path.join(args.data,'TestData/val/')
#val_label_path = os.path.join(args.data,'TestData/final_val.csv')
#val_data = data_load2(val_data_path , val_label_path, mode='train')
#random.shuffle(val_data)

'''
Enter the corresponding control program according to self.mode (train or val)
'''
if args.mode == 'train':
	#Read training and testing data
	
	print("training mode")
	saver = tf.train.Saver(tf.global_variables())
	with tf.Session(config=config) as sess:
		#if the model has checkpoint,load
		if ckpt_file == None:
			sess.run(tf.global_variables_initializer())
			pass
		else: # if exists checkpoint，load
			saver.restore(sess, ckpt_file)
		#training epoch by epoch
		model.addSummary(sess)
		min_loss = 1000   ###determine the model with the minimum loss on the test set, and then save it
		for epoch in range(args.epoch):

			logger.info('==========================================')
			logger.info('===========training on epoch {}==========='.format(epoch+global_epoch+1))
			model.train_one_epoch(sess, train_data, epoch+global_epoch+1, saver, logger)

			logger.info('==> loss on training dataset')
			predictions,labels,losses = model.predict_one_epoch(sess, train_data)  ##Calculate the loss of the training set
			train_result = print_metrics_binary(labels, predictions, verbose=1)
			train_result['losses'] = losses
			logger.info(train_result)

			logger.info('============================')
			logger.info('==> loss on testing dataset')
			predictions,labels,losses = model.predict_one_epoch(sess, test_data)  ##Calculate the loss of the test set
			test_result = print_metrics_binary(labels, predictions,verbose=1)
			test_result['losses'] = losses
			logger.info(test_result)
			test_result_save(train_result,test_result,result_path,epoch+global_epoch+1)

			if test_result['losses'] < min_loss:##Save the model with minimum loss on the test set
				saver.save(sess, model.model_path, global_step = epoch+global_epoch+1)
				min_loss = test_result['losses']
				pass
			pass
		pass
	pass
elif args.mode == 'val':
	'''
	Read validation data
	'''
	filename = []
	for item in val_data:
		filename.append(item[0])
		pass
	'''
	Begin Training
	'''
	if ckpt_file ==None:
		raise Exception("No checkpoint model was found")
		pass

	saver = tf.train.Saver()

	with tf.Session(config=config) as sess:
		logger.info('=========== verification ===========')
		saver.restore(sess, ckpt_file)
		predictions,labels,losses = model.predict_one_epoch(sess, val_data)  ##Calculate the loss of the validation set
		val_result = print_metrics_binary(labels, predictions,verbose=1)
		val_result['losses'] = losses
		logger.info(val_result)
		val_result_save(predictions,labels,filename,result_path)
		pass
	pass
else:
	raise ValueError("Wrong value [{}] for parameter args.mode".format(args.mode))